import flet as ft
import random
import time
import asyncio

def main(page: ft.Page):
    # === Page Settings ===
    page.title = "Make 24: Merge Edition"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.bgcolor = "#F4F6F8"  
    page.window.width = 650    
    page.window.height = 850
    page.padding = 20
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.scroll = ft.ScrollMode.AUTO 

    # === Core State Management ===
    state = {
        "nums": [0, 0, 0, 0],       
        "orig_nums": [0, 0, 0, 0],  
        "node_expr": ["", "", "", ""], 
        "score": 0,                 
        "sel_idx": None,            
        "sel_op": None,             
        "solution": "",
        "start_time": 0.0,          
        "best_time": float('inf'),
        "is_playing": False         
    }

    card_uis = []
    op_uis = []
    
    timer_text = ft.Text("Time: 0.0s", size=18, weight=ft.FontWeight.BOLD, color="#546E7A")

    # === DFS Solver ===
    def dfs_solve(items):
        if len(items) == 1:
            val, expr = items[0]
            if abs(val - 24.0) < 1e-6:
                return True, expr
            return False, ""

        for i in range(len(items)):
            for j in range(len(items)):
                if i == j: continue
                val1, expr1 = items[i]
                val2, expr2 = items[j]
                next_items = [items[k] for k in range(len(items)) if k != i and k != j]

                ops = [
                    (val1 + val2, f"({expr1} + {expr2})"),
                    (val1 - val2, f"({expr1} - {expr2})"),
                    (val1 * val2, f"({expr1} * {expr2})")
                ]
                if abs(val2) > 1e-6:
                    ops.append((val1 / val2, f"({expr1} / {expr2})"))

                for new_val, new_expr in ops:
                    success, final_expr = dfs_solve(next_items + [(new_val, new_expr)])
                    if success: return True, final_expr
        return False, ""

    def show_dialog(title_text, content_text, is_error=False):
        color_code = "#D32F2F" if is_error else "#388E3C" 
        dlg = ft.AlertDialog(
            title=ft.Text(title_text, color=color_code, weight=ft.FontWeight.BOLD, size=22),
            content=ft.Text(content_text, size=18)
        )
        def close_dlg(e):
            dlg.open = False
            page.update()
        
        dlg.actions = [ft.TextButton(content=ft.Text("OK"), on_click=close_dlg)]
        page.overlay.append(dlg)
        dlg.open = True
        page.update()

    def format_num(val):
        if abs(round(val) - val) < 1e-6:
            return str(int(round(val)))
        return f"{val:.2f}"

    def update_ui():
        score_text.value = f"SCORE: {state['score']}"
        
        for i in range(4):
            val = state["nums"][i]
            card = card_uis[i]
            if val is None:
                card.bgcolor = "transparent"
                card.border = None
                card.content.value = ""
            else:
                card.content.value = format_num(val)
                if state["sel_idx"] == i:
                    card.bgcolor = "#E3F2FD"
                    card.border = ft.Border(
                        top=ft.BorderSide(4, "#1976D2"), bottom=ft.BorderSide(4, "#1976D2"),
                        left=ft.BorderSide(4, "#1976D2"), right=ft.BorderSide(4, "#1976D2")
                    )
                else:
                    card.bgcolor = "white"
                    card.border = ft.Border(
                        top=ft.BorderSide(2, "#90CAF9"), bottom=ft.BorderSide(2, "#90CAF9"),
                        left=ft.BorderSide(2, "#90CAF9"), right=ft.BorderSide(2, "#90CAF9")
                    )

        for op_btn in op_uis:
            op_val = op_btn.data
            if state["sel_op"] == op_val:
                op_btn.style.bgcolor = "#FF9800"
                op_btn.style.color = "white"
            else:
                op_btn.style.bgcolor = "#BBDEFB"
                op_btn.style.color = "#0D47A1"

        page.update()

    def check_win_condition():
        remaining = [v for v in state["nums"] if v is not None]
        
        if len(remaining) == 1:
            final_val = remaining[0]
            
            user_expr = [e for e in state["node_expr"] if e is not None][0]
            if user_expr.startswith('(') and user_expr.endswith(')'):
                user_expr = user_expr[1:-1] 

            if abs(final_val - 24.0) < 1e-6:
                state["is_playing"] = False 
                state["score"] += 1
                
                time_taken = round(time.time() - state["start_time"], 1)
                time_msg = f"{time_taken}s"
                timer_text.value = f"Time: {time_taken:.1f}s"
                
                is_new_best = False
                if time_taken < state["best_time"]:
                    is_new_best = True
                    if state["best_time"] != float('inf'):
                        diff = round(state["best_time"] - time_taken, 1)
                        time_msg += f" (-{diff}s)"
                    
                    state["best_time"] = time_taken
                    best_record_text.value = f"[FASTEST] {time_taken}s | {user_expr} = 24"
                    best_record_text.color = "#D84315" 
                
                log_color = "#D84315" if is_new_best else "#2E7D32"
                log_entry = f"#{state['score']} | {time_msg} | {user_expr}"
                
                # 【ListView 插入方法】：向最前面插入新纪录
                log_list.controls.insert(0, ft.Text(log_entry, size=15, color=log_color, weight=ft.FontWeight.W_500))
                
                show_dialog("Success!", f"Perfect! Solved in {time_taken} seconds.")
                generate_new_game(None)
            else:
                show_dialog("Incorrect", f"Result is {format_num(final_val)}.\nClick [Reset Level] to try again!", is_error=True)
                state["sel_idx"] = None
                state["sel_op"] = None
                update_ui()

    def on_card_click(e):
        idx = e.control.data
        if state["nums"][idx] is None:
            return 

        if state["sel_op"] is None:
            state["sel_idx"] = idx
        else:
            if state["sel_idx"] == idx:
                state["sel_op"] = None
            else:
                v1 = state["nums"][state["sel_idx"]]
                v2 = state["nums"][idx]
                expr1 = state["node_expr"][state["sel_idx"]]
                expr2 = state["node_expr"][idx]
                op = state["sel_op"]
                
                try:
                    if op == '+': res = v1 + v2
                    elif op == '-': res = v1 - v2
                    elif op == '×': res = v1 * v2
                    elif op == '÷':
                        if abs(v2) < 1e-6: raise ZeroDivisionError
                        res = v1 / v2

                    state["nums"][idx] = res
                    state["node_expr"][idx] = f"({expr1} {op} {expr2})"
                    state["nums"][state["sel_idx"]] = None
                    state["node_expr"][state["sel_idx"]] = None
                    
                    state["sel_idx"] = None
                    state["sel_op"] = None
                    
                    update_ui()
                    check_win_condition()
                    return 
                
                except ZeroDivisionError:
                    show_dialog("Math Error", "Cannot divide by zero!", is_error=True)
                    state["sel_op"] = None

        update_ui()

    def on_op_click(e):
        if state["sel_idx"] is None:
            show_dialog("Hint", "Please select a number card first!", is_error=True)
            return
        state["sel_op"] = e.control.data
        update_ui()

    def reset_game(e):
        state["nums"] = state["orig_nums"].copy()
        state["node_expr"] = [str(n) for n in state["orig_nums"]]
        state["sel_idx"] = None
        state["sel_op"] = None
        update_ui()

    def show_solution_action(e):
        show_dialog("Solution Hint", f"One possible way:\n\n{state['solution']} = 24")

    def generate_new_game(e):
        while True:
            nums = [random.randint(1, 10) for _ in range(4)]
            items = [(float(n), str(n)) for n in nums]
            success, expr = dfs_solve(items)
            
            if success:
                state["orig_nums"] = nums.copy()
                state["nums"] = nums.copy()
                state["node_expr"] = [str(n) for n in nums] 
                state["sel_idx"] = None
                state["sel_op"] = None
                
                if expr.startswith('(') and expr.endswith(')'):
                    expr = expr[1:-1]
                state["solution"] = expr
                
                state["start_time"] = time.time()
                state["is_playing"] = True 
                
                update_ui()
                break

    async def timer_loop():
        while True:
            if state["is_playing"]:
                elapsed = time.time() - state["start_time"]
                timer_text.value = f"Time: {elapsed:.1f}s"
                page.update() 
            await asyncio.sleep(0.1)

    # === UI Components ===
    title_text = ft.Text("MAKE 24: MERGE", size=28, weight=ft.FontWeight.W_900, color="#263238")
    score_text = ft.Text("SCORE: 0", size=18, weight=ft.FontWeight.BOLD, color="#E65100")
    
    header_row = ft.Row(
        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
        controls=[
            ft.Column([title_text, timer_text], spacing=0), 
            ft.Container(content=score_text, bgcolor="#FFE0B2", padding=10, border_radius=15)
        ],
        width=500
    )

    cards_row = ft.Row(alignment=ft.MainAxisAlignment.CENTER, spacing=15)
    for i in range(4):
        card = ft.Container(
            content=ft.Text("", size=45, weight=ft.FontWeight.BOLD, color="#1565C0"),
            width=100, height=130,
            alignment=ft.Alignment(0, 0), # 坐标绝对居中
            border_radius=15,
            data=i, 
            on_click=on_card_click
        )
        card_uis.append(card)
        cards_row.controls.append(card)

    op_row = ft.Row(alignment=ft.MainAxisAlignment.CENTER, spacing=20)
    for op in ["+", "-", "×", "÷"]:
        btn = ft.FilledButton(
            content=ft.Text(op, size=35, weight=ft.FontWeight.BOLD),
            width=80, height=80,
            style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=15)),
            data=op, 
            on_click=on_op_click
        )
        op_uis.append(btn)
        op_row.controls.append(btn)

    ctrl_row = ft.Row(
        alignment=ft.MainAxisAlignment.CENTER, spacing=20,
        controls=[
            ft.ElevatedButton(
                content=ft.Text("Reset Level", size=16, weight=ft.FontWeight.BOLD), 
                width=160, height=55, 
                style=ft.ButtonStyle(bgcolor="#FFCA28", color="black"), 
                on_click=reset_game
            ),
            ft.ElevatedButton(
                content=ft.Text("New Game", size=16, weight=ft.FontWeight.BOLD), 
                width=160, height=55, 
                style=ft.ButtonStyle(bgcolor="#4CAF50", color="white"), 
                on_click=generate_new_game
            ),
        ]
    )
    
    sol_row = ft.Row(
        alignment=ft.MainAxisAlignment.CENTER,
        controls=[
            ft.OutlinedButton(
                content=ft.Text("Show Solution", size=16, weight=ft.FontWeight.BOLD), 
                width=340, height=50, 
                on_click=show_solution_action
            )
        ]
    )

    best_record_text = ft.Text("[FASTEST] -- | --", size=16, weight=ft.FontWeight.BOLD, color="#9E9E9E")
    
    # === 【终极修复】：改用 ListView 确保滚动条完美贴在最右侧 ===
    log_list = ft.ListView(spacing=8, expand=True)
    
    log_container = ft.Container(
        content=ft.Column([
            ft.Row([ft.Text("VICTORY LOG", size=18, weight=ft.FontWeight.BOLD, color="#1B5E20")]),
            best_record_text, 
            ft.Divider(color="#A5D6A7"),
            log_list # ListView 自动撑满 Container 的 500 宽度
        ]),
        width=500, height=220, 
        bgcolor="#E8F5E9",
        border_radius=15,
        padding=15,
        border=ft.Border(
            top=ft.BorderSide(width=2, color="#81C784"), bottom=ft.BorderSide(width=2, color="#81C784"),
            left=ft.BorderSide(width=2, color="#81C784"), right=ft.BorderSide(width=2, color="#81C784"),
        )
    )

    page.add(
        ft.Column(
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=30,
            controls=[header_row, cards_row, op_row, ctrl_row, sol_row, log_container]
        )
    )

    page.run_task(timer_loop)
    generate_new_game(None)

if __name__ == "__main__":
    ft.run(main)