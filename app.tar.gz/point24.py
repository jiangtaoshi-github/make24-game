
import flet as ft
import random

def main(page: ft.Page):
    # === Page Settings ===
    page.title = "Make 24 - Ultimate Edition"
    page.theme_mode = ft.ThemeMode.LIGHT
    page.bgcolor = "#F4F6F8"  
    
    # 缩小全局内边距
    page.padding = 20
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    # 依然保留自动滚动，以防在极小屏幕（如手机）上完全挤不进去
    page.scroll = ft.ScrollMode.AUTO 

    # === Game State ===
    current_numbers = []
    input_history = []  
    num_buttons = []    
    current_score = 0   

    def dfs_solve(items):
        if len(items) == 1:
            val, expr = items[0]
            if abs(val - 24.0) < 1e-6:
                return True, expr
            return False, ""

        for i in range(len(items)):
            for j in range(len(items)):
                if i == j: continue
                val1, expr1 = items[i]
                val2, expr2 = items[j]
                next_items = [items[k] for k in range(len(items)) if k != i and k != j]

                ops = [
                    (val1 + val2, f"({expr1} + {expr2})"),
                    (val1 - val2, f"({expr1} - {expr2})"),
                    (val1 * val2, f"({expr1} * {expr2})")
                ]
                if abs(val2) > 1e-6:
                    ops.append((val1 / val2, f"({expr1} / {expr2})"))

                for new_val, new_expr in ops:
                    success, final_expr = dfs_solve(next_items + [(new_val, new_expr)])
                    if success: return True, final_expr
        return False, ""

    def update_screen():
        expression = " ".join([item[1] for item in input_history])
        screen_text.value = expression
        page.update()

    def show_dialog(title_text, content_text, is_error=False):
        color_code = "#D32F2F" if is_error else "#388E3C" 
        
        dlg = ft.AlertDialog(
            title=ft.Text(title_text, color=color_code, weight=ft.FontWeight.BOLD, size=22), # 弹窗字号微调
            content=ft.Text(content_text, size=18)
        )
        
        def close_dlg(e):
            dlg.open = False
            page.update()
            
        dlg.actions = [ft.TextButton(content=ft.Text("OK"), on_click=close_dlg)]
        
        page.overlay.append(dlg)
        dlg.open = True
        page.update()

    def click_number(e, idx):
        val = str(current_numbers[idx])
        input_history.append(('num', val, idx))
        num_buttons[idx]['btn'].disabled = True
        update_screen()

    def click_operator(e, op):
        input_history.append(('op', op, None))
        update_screen()

    def backspace(e):
        if input_history:
            item_type, val, idx = input_history.pop()
            if item_type == 'num':
                num_buttons[idx]['btn'].disabled = False
            update_screen()

    def clear_screen(e=None):
        input_history.clear()
        for item in num_buttons:
            item['btn'].disabled = False
        update_screen()

    def verify_input(e):
        nonlocal current_score 

        expression = "".join([item[1] for item in input_history])
        if not expression:
            return

        used_indices = [item[2] for item in input_history if item[0] == 'num']
        if len(used_indices) != 4 or len(set(used_indices)) != 4:
            show_dialog("Rule Error", "You MUST use all 4 cards exactly once!", is_error=True)
            return

        try:
            result = eval(expression)
            if abs(result - 24.0) < 1e-6:
                current_score += 1
                score_text.value = f"SCORE: {current_score}"
                
                log_column.controls.insert(0, ft.Text(f"WIN #{current_score}:  {expression} = 24", size=16, color="#2E7D32", weight=ft.FontWeight.BOLD))
                
                show_dialog("Success!", "Great job! The result is exactly 24!")
                generate_new_game(None)
            else:
                show_dialog("Incorrect", f"The result is {result:.2f}, not 24. Try again!", is_error=True)
        except ZeroDivisionError:
            show_dialog("Math Error", "Cannot divide by zero!", is_error=True)
        except Exception:
            show_dialog("Syntax Error", "Invalid expression format. Check your parentheses!", is_error=True)

    def show_solution(e):
        items = [(float(n), str(n)) for n in current_numbers]
        success, expr = dfs_solve(items)
        if success:
            if expr.startswith('(') and expr.endswith(')'):
                expr = expr[1:-1]
            show_dialog("Solution", f"One possible solution is:\n\n{expr} = 24")

    def generate_new_game(e):
        clear_screen()
        while True:
            nums = [random.randint(1, 10) for _ in range(4)]
            items = [(float(n), str(n)) for n in nums]
            success, _ = dfs_solve(items)
            
            if success:
                current_numbers.clear()
                current_numbers.extend(nums)
                for i in range(4):
                    num_buttons[i]['text'].value = str(nums[i])
                    num_buttons[i]['btn'].disabled = False
                page.update()
                break

    # === 构建现代 UI 组件 (紧凑版) ===
    
    title_text = ft.Text("MAKE 24", size=36, weight=ft.FontWeight.W_900, color="#263238") # 字号缩小
    score_text = ft.Text("SCORE: 0", size=22, weight=ft.FontWeight.BOLD, color="#E65100")
    score_badge = ft.Container(
        content=score_text,
        bgcolor="#FFE0B2",
        padding=10, # 内边距缩小
        border_radius=15,
        border=ft.Border(
            top=ft.BorderSide(width=2, color="#FF9800"),
            bottom=ft.BorderSide(width=2, color="#FF9800"),
            left=ft.BorderSide(width=2, color="#FF9800"),
            right=ft.BorderSide(width=2, color="#FF9800"),
        )
    )
    header_row = ft.Row(
        alignment=ft.MainAxisAlignment.SPACE_BETWEEN,
        controls=[title_text, score_badge],
        width=750 # 整体宽度略微缩窄使布局更紧凑
    )

    cards_row = ft.Row(alignment=ft.MainAxisAlignment.CENTER, spacing=20)
    for i in range(4):
        card_text = ft.Text(value="", size=50, weight=ft.FontWeight.BOLD) # 字号缩小
        btn = ft.ElevatedButton(
            content=card_text, 
            width=120, height=128, # 高度从200降至128，宽度从150降至120
            style=ft.ButtonStyle(
                shape=ft.RoundedRectangleBorder(radius=15),
                color="#1565C0",
                bgcolor={"":"white", "disabled":"#E0E0E0"},
                elevation=8,
                padding=0,
            ),
            on_click=lambda e, idx=i: click_number(e, idx)
        )
        num_buttons.append({'btn': btn, 'text': card_text})
        cards_row.controls.append(btn)

    screen_text = ft.Text("", size=35, weight=ft.FontWeight.BOLD, color="#263238") # 字号缩小
    screen_container = ft.Container(
        content=screen_text,
        width=750, height=90, # 高度从120降至90
        bgcolor="white",
        border_radius=15,
        alignment=ft.Alignment(0, 0), 
        border=ft.Border(
            top=ft.BorderSide(width=3, color="#90CAF9"),
            bottom=ft.BorderSide(width=3, color="#90CAF9"),
            left=ft.BorderSide(width=3, color="#90CAF9"),
            right=ft.BorderSide(width=3, color="#90CAF9"),
        ),
        shadow=ft.BoxShadow(spread_radius=1, blur_radius=10, color="#B0BEC5")
    )

    op_row = ft.Row(alignment=ft.MainAxisAlignment.CENTER, spacing=15)
    for op in ["+", "-", "×", "÷", "(", ")"]:
        op_row.controls.append(
            ft.FilledButton(
                content=ft.Text(op, size=30, weight=ft.FontWeight.BOLD), # 字号缩小
                width=80, height=65, # 高度降至65
                style=ft.ButtonStyle(
                    shape=ft.RoundedRectangleBorder(radius=12),
                    bgcolor="#BBDEFB",
                    color="#0D47A1",
                ),
                on_click=lambda e, o=op: click_operator(e, o)
            )
        )

    ctrl_row = ft.Row(
        alignment=ft.MainAxisAlignment.CENTER, spacing=20,
        controls=[
            ft.ElevatedButton(
                content=ft.Text("Undo", size=18, weight=ft.FontWeight.BOLD), 
                width=180, height=55, # 高度降至55
                style=ft.ButtonStyle(bgcolor="#FFCA28", color="black"), 
                on_click=backspace
            ),
            ft.ElevatedButton(
                content=ft.Text("Clear", size=18, weight=ft.FontWeight.BOLD), 
                width=180, height=55, 
                style=ft.ButtonStyle(bgcolor="#EF5350", color="white"), 
                on_click=clear_screen
            ),
            ft.ElevatedButton(
                content=ft.Text("Verify", size=18, weight=ft.FontWeight.BOLD), 
                width=180, height=55, 
                style=ft.ButtonStyle(bgcolor="#4CAF50", color="white"), 
                on_click=verify_input
            ),
        ]
    )

    bottom_row = ft.Row(
        alignment=ft.MainAxisAlignment.CENTER, spacing=20,
        controls=[
            ft.OutlinedButton(
                content=ft.Text("New Game", size=16, weight=ft.FontWeight.BOLD), 
                width=200, height=50, # 高度降至50
                on_click=generate_new_game
            ),
            ft.OutlinedButton(
                content=ft.Text("Solution", size=16, weight=ft.FontWeight.BOLD), 
                width=200, height=50, 
                on_click=show_solution
            ),
        ]
    )

    log_column = ft.Column(spacing=8, scroll=ft.ScrollMode.AUTO)
    log_container = ft.Container(
        content=ft.Column([
            ft.Text("VICTORY LOG", size=18, weight=ft.FontWeight.BOLD, color="#1B5E20"),
            ft.Divider(color="#A5D6A7"),
            log_column
        ]),
        width=750, height=140, # 日志面板高度适当调低
        bgcolor="#E8F5E9",
        border_radius=15,
        padding=15,
        border=ft.Border(
            top=ft.BorderSide(width=2, color="#81C784"),
            bottom=ft.BorderSide(width=2, color="#81C784"),
            left=ft.BorderSide(width=2, color="#81C784"),
            right=ft.BorderSide(width=2, color="#81C784"),
        )
    )

    page.add(
        ft.Column(
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=15, # 核心优化点：列内组件的垂直间距大幅度缩小
            controls=[
                header_row,
                cards_row,
                screen_container,
                op_row,
                ctrl_row,
                bottom_row,
                log_container 
            ]
        )
    )

    generate_new_game(None)

if __name__ == "__main__":
    ft.run(main)

